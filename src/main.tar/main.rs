#![feature(extern_prelude)]
#![allow(non_upper_case_globals)]
#![allow(non_camel_case_types)]
#![allow(non_snake_case)]

extern crate bit_vec;


pub mod array;
use bit_vec::BitVec;


///
///
///
fn main() 
{
	let bv = BitVec::from_elem(16384, false); // 2^14
	assert_eq!(bv.len(), 16384);

	for x in &bv 
	{
    	assert_eq!(x, false);
	}

}
